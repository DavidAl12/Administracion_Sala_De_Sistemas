﻿namespace Services.Models.FarmModels
{
    public class AddFarmModel
    {
        public string Name { get; set; }
        public string Location { get; set; }
    }
}
